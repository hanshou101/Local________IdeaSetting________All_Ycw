#set(
 $capDirName = $dirName.substring(0,1).toUpperCase() + $dirName.substring(1)
)

import request                 from 'umi-request';
import {CRUD_Helper}           from '@/components/ycw/CommonProTable/CRUD_Helper';
import type {ListItemDataType} from './data.d';

export async function queryFake${capDirName}List(params : ListItemDataType) {
  return request('/api/fake_${dirName}_list', {
    params,
  });
}

export const ${capDirName}CRUD = CRUD_Helper.crudApi<ListItemDataType>('/${dirName}');
