#set(
 $capDirName = $dirName.substring(0,1).toUpperCase() + $dirName.substring(1)
)

import type {Request, Response} from 'express';
import type {ListItemDataType}  from './data.d';


function fakeList(
  count : number
) : ListItemDataType[]{
  return (Array(count) as ListItemDataType[]).fill({
    id: `${DS}{Math.random() * (10 ** 16)}`,
  },);
}

/**
 * 该方法，适合抽取出来
 */
function getFake${capDirName}List(req : Request, res : Response){
  const params = req.query;

  const count = Number(params.count) * 1 || 20;

  const result = fakeList(count);
  return res.json(result);
}


export default {
  'GET  /api/fake_${dirName}_list': getFake${capDirName}List,
};
