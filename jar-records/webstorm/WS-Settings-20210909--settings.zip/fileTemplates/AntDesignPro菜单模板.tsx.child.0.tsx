#set(
 $capDirName = $dirName.substring(0,1).toUpperCase() + $dirName.substring(1)
)


import type {FC}                         from 'react';
import React                             from 'react';
import {PageContainer}                   from '@ant-design/pro-layout';
import type {Dispatch}                   from 'umi';
import {connect, /* FormattedMessage */} from 'umi';

import CommonProTable                               from '@/components/ycw/CommonProTable';
import type {StateType as ProjectStateType}         from '@/pages/radar/project/model';
import {${capDirName}CRUD}                          from './service';
import type {StateType}                             from './model';
import type {ListItemDataType}                      from './data.d';
import {Table_Helper}                               from '@/components/ycw/CommonProTable/Table_Helper';
import {Divider}                                    from 'antd';

const {list: getList, create, update, del} = ${capDirName}CRUD;
const {tutorial: {descLinks, descTexts,genUtilUI,genLinkUI}}   = Table_Helper;

type ${capDirName}Props = {
  dispatch : Dispatch;
  listAnd${modelNS} : StateType,
  // listAndproject : ProjectStateType,
  loading : {models : Record<string, boolean>};
  isLoading : boolean;
}

const utils = [
  {
    keywords: '【子域名、旁站、C段，综合查询】',
    desc    : [
      ...descTexts([
      
      ]),
      ...descLinks([
       
      ]),
    ],
  },
];

const sites = [
  {
    keywords: '【社工库查询】',
    desc    : descLinks([
      {
        href: 'http://site3.sjk.space/sgk1.php',
        name: '社工库免费查询',
        rate:
          '低价值，试验性作品。不指望能查出 真正有价值的东西 ，只是一个展示',
        opt : {
          outdated: true,
        },
      },
    ]),
  },
];

const ${capDirName} : FC<${capDirName}Props> = ({
  dispatch, 
  listAnd${modelNS}: {list}, 
  // listAndproject: {list: projectList},
  isLoading,
} : Omit<${capDirName}Props, 'loading'>)=>{

  /*
      // 拉取Project
      const fetchProjects = ()=>{
        dispatch({
          type   : 'listAndproject/fetch',
          payload: {},
        });
      };
    
      // 会在【渲染到屏幕】之后执行。
      useEffect(()=>{
        fetchProjects();
      }, []);
  */

  return (
    <PageContainer
      content={
        <div style={{whiteSpace: 'pre-line'}}>
          {`
         服务器基本信息扫描
          
         【真实IP】
         【系统类型】、【系统版本】
         【开放端口】
         【WAF防火墙】Web Application Firewall
         `}
          <Divider type="horizontal"/>
          <h1>工具</h1>
          <div>{utils.map(genUtilUI)}</div>
          {/**/}
          <Divider type="horizontal"/>
          <h1>网站</h1>
          <div>{sites.map(genLinkUI)}</div>
        </div>
      }>
      <CommonProTable<ListItemDataType>
        handleAdd={create}
        handleUpdate={update}
        handleRemove={del}
        handleList={(params, sorter, filter)=>getList(params).then(res=>({
          data   : res,
          success: true,
          total  : res.length,
        }))}
        columns={[
          {
            title     : '唯一ID',
            dataIndex : 'id',
            valueType : 'text',
            fieldProps: {
              disabled: true,   // 直接传递到<Input>组件，无疑是一种非常聪明的做法。
            },
            width     : '150px',
          },
          {
            title    : '项目ID',
            dataIndex: 'projectId',
            // 枚举字段（从列表中，可以拉取）
            valueEnum: {
              0: {text: '关闭', status: 'Default'},
              1: {text: '运行中', status: 'Processing'},
              2: {text: '已上线', status: 'Success'},
              3: {text: '异常', status: 'Error'},
            },
            // valueEnum: projectList.reduce((pre, current)=>{
            //   return {
            //     ...pre,
            //     [current.id]: {
            //       text  : current.name,
            //       status: 'Success',
            //     }
            //   };
            // }, {} as any),
          },
          {
            title    : '真实IP',
            dataIndex: 'trueIP',
            valueType: 'text',
          },
          {
            title    : '系统类型',
            dataIndex: 'systemType',
            valueType: 'textarea',
            render   : Table_Helper.get_pRenderFn(),
          },
          {
            title     : '创建时间',
            dataIndex : 'createdAt',
            valueType : 'dateTime',
            hideInForm: true,
          },
          {
            title     : '更新时间',
            dataIndex : 'updatedAt',
            valueType : 'dateTime',
            hideInForm: true,
          },
        ]}
      />
    </PageContainer>
  );
};


export default connect(({
  listAnd${modelNS},
  // listAndproject,
  loading,
} : Omit<${capDirName}Props, 'isLoading'|'dispatch'>
)=>({
  listAnd${modelNS},
  // listAndproject,
  loading: loading.models.listAndserver,
}))(${capDirName});
