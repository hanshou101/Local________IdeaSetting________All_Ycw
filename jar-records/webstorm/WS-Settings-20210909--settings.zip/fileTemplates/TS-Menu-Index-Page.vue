<template>
  <keep-alive :include="cachedViews">
    <!--TIP 提示，尝试只在Router的最顶层入口：【AppMain】，设置key。不然指数效应的路由树，内存开销过大。-->
    <router-view></router-view>
  </keep-alive>
</template>

<script lang="ts">

  import BaseVue, {MixinLevelTag, MyComponent} from "@/_framework/BaseVue";

  @MyComponent({
    name:       "${NAME}",
    components: {
      /*组件*/
    },
    filters:    {},
  })
// export default class HelloWorld extends BaseVueClass {
  export default class ${NAME}
    extends BaseVue {    // 混入在此处，进行添加。


    // Data，在类中的实现 （双向绑定除外）

    get cachedViews () {
      return this.${DS}store.state.tagsView.cachedViews;
    }//
    get key () {
      return this.${DS}route.fullPath;
    }

    // Method，在类中的实现

    // Lifecycle生命周期，在类中的实现

    created (): void {
    };

    mounted (): void {
    };

    activated (): void {
    };

    updated (): void {
    };

    destroyed (): void {
    };

    MixinsData_1: MixinLevelTag = {} as any;



  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="stylus">
  /* TODO 此处，全部采用【BEM】式的命名法。  Block__Element--Modifier */

  /* TODO 尽量采用，Stylus-函数式编程 */

  .block__element--modifier {

  }

</style>
