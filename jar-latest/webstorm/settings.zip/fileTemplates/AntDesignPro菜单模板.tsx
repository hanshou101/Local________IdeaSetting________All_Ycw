/**
 * WebStorm模板，输入以下自定义变量：
 * ${dirName} 目录名 
 * ${modelNS} Model命名空间
 */

#set(
 $capDirName = $dirName.substring(0,1).toUpperCase() + $dirName.substring(1)
)

import type {FC}                         from 'react';
import React, {useEffect}                from 'react';
import {PageContainer}                   from '@ant-design/pro-layout';
import type {Dispatch}                   from 'umi';
import {connect, /* FormattedMessage */} from 'umi';
import {Card, Form, List, Select, Tag}   from 'antd';
import StandardFormRow                   from '@/pages/list/search/articles/components/StandardFormRow';
import styles                            from './style.less';
import type {ListItemDataType}           from './data.d';

import type {StateType}   from './model';

type ${capDirName}Props = {
  dispatch : Dispatch;
  listAnd${dirName} : StateType,
  loading : boolean;
}

const ${capDirName} : FC<${capDirName}Props> = ({dispatch, listAnd${dirName}: {list}, loading})=>{
  // 获取表单
  const [form] = Form.useForm();

  // 会在【渲染到屏幕】之后执行。
  useEffect(()=>{
    dispatch({
      type   : 'listAnd${dirName}/fetch',
      payload: {
        count: 5,
      },
    });
  }, []);

  /**
   * 下拉框，的候选项
   */
  const types = [
    {
      id  : '1',
      name: '下拉一',
    },
    {
      id  : '2',
      name: '下拉二',
    },
  ];


  return (
    <PageContainer
      content={
        <span>项目基本资料汇总。</span>
      }>
      <React.Fragment>
        {/* 卡片，搜索 */}
        <Card bordered={false}>
          {/* 表单 */}
          <Form
            layout='inline'
            form={form}
            /* 初始值 */
            initialValues={{
              types: ['1', '2'],
            }}
            /* 任何搜索项变动，都触发 */
            onValuesChange={()=>{
              console.log('搜索项变化了');
            }}
          >
            <StandardFormRow title='类别' grid>
              <Form.Item name='type' noStyle>
                {/* 下拉框 */}
                <Select className={styles.searchInput} mode='multiple' placeholder='选择 type'>
                  {types.map((type)=>(
                    /* 下拉项 */
                    <Select.Option key={type.id} value={type.id}>
                      {type.name}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </StandardFormRow>
          </Form>
        </Card>
        {/* 卡片，列表 */}
        <Card
          style={{marginTop: 24}}
          bordered={false}
          bodyStyle={{padding: '8px 32px 32px 32px'}}
        >
          {/* 列表 */}
          <List<ListItemDataType>
            /* 尺寸 */
            size='large'
            loading={list.length === 0 ? loading : false}
            /* 每行key */
            rowKey='id'
            /* 条目布局方向 */
            itemLayout='vertical'
            /* 加载更多，功能 */
            /* loadMore={loadMore} */
            dataSource={list}
            renderItem={(item)=>(
              /* 列表项 */
              <List.Item
                key={item.id}
                /* 左下角项 */
                actions={[
                  <span>项目一</span>,
                  <span>项目二</span>,
                  <span>项目三</span>,
                ]}
                /* 右侧内容 */
                extra={
                  <div className={styles.listItemExtra}>右侧</div>
                }
              >
                {/* 更灵活的内容 */}
                <List.Item.Meta
                  /* 标题 */
                  title={
                    /* 文字 */
                    <a className={styles.listItemMetaTitle} href={''}>
                      {item.name}
                    </a>
                  }
                  /* 描述 */
                  description={
                    <span>
                      {
                        /* 标签 */
                        item.descTags.map(t=>(<Tag>{t}</Tag>))
                      }
                  </span>
                  }
                />
                {/* 内容 */}
                123
              </List.Item>
            )}>
          </List>
        </Card>
      </React.Fragment>
    </PageContainer>
  );
};


export default connect(({
  listAnd${dirName},
  loading,
} : {
  listAnd${dirName} : StateType,
  loading : {models : Record<string, boolean>};
})=>({
  listAnd${dirName},
  loading: loading.models.listAnd${dirName},
}))(${capDirName});
