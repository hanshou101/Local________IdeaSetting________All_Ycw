<!--制作注意：在模板文件里，用${DS}{DS}来表示单纯美元符号，用${DS}name来指代变量（注意一个词：迭代）-->
<!--TIP注释的使用：①-重要信息和描述 ②-适合给方法加注释 ③-不要过度使用，不要给HTML标签TIP加注释 ④-  -->
<template>
  <div class="block__element--modifier common-main">
    <!--总表单-->
    <el-form :model="ruleForm" :rules="rules" ref="ruleFormRef"
             label-width="100px" class="search-container">
      <MyFormEasy :form-items="formItems" :ruleForm="ruleForm"></MyFormEasy>
      <div class="operation-container"><!--操作按钮组：搜索、新建、删除-->
        <el-button icon="el-icon-search" @click="submitForm('ruleFormRef')">{{${DS}t('form.Search')}}</el-button><!--搜索-->
        <el-button type="primary" icon="el-icon-edit" @click="openDialog(1,{})">{{${DS}t('form.Create')}}</el-button><!--新建-->
        <el-button type="danger" icon="el-icon-delete" @click="handleDelete">{{${DS}t('form.Delete')}}</el-button><!--删除-->
      </div>
    </el-form>

    <!--总表格-->
    <el-table :data="listData" @selection-change="handleSelectionChange" v-loading="listLoading"
              tooltip-effect="dark"
              ref="multipleTable"
              class="element-table-list" style="width: 100%;">
      <MyTableEasy :table-cols="tableCols">
        <template #operate="scope">
          <!--<Dropdown>
            &lt;!&ndash;编辑&ndash;&gt;
            <el-button @click="handleEdit(scope.${DS}index, scope.row)"  slot="dropdown-item" size="mini" type="primary"icon="el-icon-edit">{{${DS}t('table.Edit')}}</el-button>
            &lt;!&ndash;启用&ndash;&gt;
            <el-button v-if="scope.row.status===0" @click="handleChangeStatus(scope.${DS}index, scope.row)" slot="dropdown-item" size="mini" icon="el-icon-edit">{{${DS}t('table.Enable')}}</el-button>
            &lt;!&ndash;禁用&ndash;&gt;
            <el-button v-if="scope.row.status===1" @click="handleChangeStatus(scope.${DS}index, scope.row)" slot="dropdown-item" size="mini" type="danger" icon="el-icon-edit">{{${DS}t('table.Disable')}}</el-button>
          </Dropdown>-->

          <!--编辑-->
          <el-button @click="openDialog( 2 , scope.row)" slot="dropdown-item" size="mini" type="primary" icon="el-icon-edit">{{ ${DS}t('table.Edit') }}</el-button>
          <!--启用-->
          <el-button v-if="scope.row.status===0" @click="handleChangeStatus(scope.${DS}index, scope.row)" slot="dropdown-item" size="mini" icon="el-icon-edit">{{${DS}t('table.Enable')}}</el-button>
          <!--禁用-->
          <el-button v-if="scope.row.status===1" @click="handleChangeStatus(scope.${DS}index, scope.row)" slot="dropdown-item" size="mini" type="danger" icon="el-icon-edit">{{${DS}t('table.Disable')}}</el-button>
          <!--删除单个-->
          <el-button @click="deleteSingle( scope.${DS}index, scope.row.id )" slot="dropdown-item" type="danger" icon="el-icon-delete" >{{ ${DS}t('form.Delete') }}</el-button><!--删除-->
        </template>
      </MyTableEasy>
    </el-table>

    <!--分页器。当选中页码更改时，会立即触发_getList刷新。-->
    <el-pagination :current-page.sync="listQuery.current" :page-size="listQuery.size" :total="listQuery.total" @current-change="handlePageChange"
                   layout="total,prev, pager, next"
                   background
                   class="pagination-container"/>

    <!--Dialog总控制器。当触发【新建】、【更改】操作时，会触发父组件的_getList刷新。-->

    <!--TODO 解开这里，即可召唤神龙实现你的愿望。-->
    <!--<YourDialog
        ref="dialogRef"
        v-if="dialogVisible"
        :show.sync="dialogVisible"
        :init-data="dialogData"
        :dialog-type="dialogType"
        @refreshList="_getList">
    </YourDialog>-->
  </div>
</template>

<script lang="ts">
  import {MyEl_FormItem, MyEl_FormItem_Rule_Config} from "../../src/_framework/sdk/elment-ui/MyElementUtils";
  import BaseVue, {MyComponent}                     from "@/_framework/BaseVue";
  import CommonMixin                                from "@/_mixin/common-mixin";
  import {ElFItem}                                  from '@/_framework/sdk/elment-ui/new/ElFItem';
  import {ElTItem}                                  from '@/_framework/sdk/elment-ui/new/ElTItem'

  @MyComponent({
    name:       "${NAME}",
    components: { /*组件*/

    },
    filters:    {},
  })
  export default class ${NAME}
    extends BaseVue.Mixins(CommonMixin) {    // 混入在此处，进行添加。
    // TIP————————————————————————————————————Prop，从外界传入的只读属性—————————————————————————————————

    // TIP————————————————————————————————————Data，在类中的实现（@Model相关的除外）——————————————————————
    ruleForm = {};

    // 控制对话弹窗显示
    public dialogVisible = false;
    // 对话弹窗数据
    public dialogData    = {} as any;
    // 对话弹窗类型（1-新建 2-编辑）
    public dialogType    = 1;

    // TIP————————————————————————————————————computed，在类中的实现（@Model相关的除外）——————————————————————
    get rules (): MyEl_FormItem_Rule_Config {
      return { // 示范
        // demo: [new MyEl_RuleItem(this.${DS}t("websiteOperation.articleManager.Select_Category").toString(),)],
      }
    }//
    get formItems (): ElFItem.Base[] {
      return [
        new ElFItem.Text({name: "id", label: "用户ID"}),
        new ElFItem.Text({name: "userName", label: "用户名"}),
        new ElFItem.Text({name: "realName", label: "真实姓名"}),
        new ElFItem.Text({name: "mobile", label: "手机号"}),
        new ElFItem.Text({name: "email", label: "邮箱"}),
        new ElFItem.Options({
          name: "status", label: "审核状态", selectOptionConf: {
            option:       this.selectOption.status,
            needParseInt: true,
          }
        }),
        new ElFItem.DateRange({name: "dateRange", label: "时间范围"}),
      ];
    }//
    get tableCols (): ElTItem.Base[] {
      return [
        new ElTItem.Text({name: "id", label: "用户ID"}),
        new ElTItem.Text({name: "userName", label: "用户名"}),
        new ElTItem.Text({name: "mobile", label: "手机号"}),
        new ElTItem.Text({name: "email", label: "邮箱"}),
        new ElTItem.Text({name: "realName", label: "真实姓名"}),
        new ElTItem.Text({name: "idCard", label: "证件号码"}),
        new ElTItem.Text({name: "authTime", label: "审核时间"}),
        new ElTItem.EnumTag({name: "authStatus", label: "实名认证状态", selectOption: this.selectOption.status}),
        new ElTItem.Custom({name: "operate", label: "操作"}, {
          i18nKey: "table.Operation", minWidth: 120, elementTableColumnAttrs: {
            fixed: "right",
            align: "center",
          }
        }),
      ];
    }

    // TIP——————————————————————————————————————Method，在类中的实例——————————————————————————————————————
    // 打开对话弹窗
    public openDialog (type: number, row: any) {
      this.dialogType    = type;
      this.dialogData    = row;
      this.dialogVisible = true;
    }

    // TIP——————————————————————————————————————Vue生命周期，在类中的实现——————————————————————————————————
    created (): void {
      this.initFunc();
    };

    mounted (): void {
    };

    activated (): void {
    };

    updated (): void {
    };

    destroyed (): void {
    };

    // TIP————————————————————————————————————————初始化Mixin的上下级关系————————————————————————————
    initFunc () {
      this.MixinsData_1 = {...this.MixinsData_1};       // TODO 顶级Mixins的数据初始化
      this.MixinsData_2 = {                             // TODO 二级Mixins的数据初始化
        ...this.MixinsData_2,
        lang:            "",                       // 后台管理系统，当前界面语种
        listCallback:    () => {                                            // 菜单第一时间，自动拉取的列表接口
          // return ArticleApi.list(this.ruleForm, this.listQuery.current, this.listQuery.size);
        },
        needListProcess: (res: any) => {                            // 如果，在列表接口之后，需要对返回的数据进行【预处理】
          return res;                                                       // 注意，若没有预处理过程，则返回原始数据即可。
        },
        changeStatusCallback (id: string, status: string) {          // 更新单个菜单条目的状态（如禁用、启用）的接口
          // return ArticleApi.changeStatus({id, status,});
        },
        deleteCallback (ids: any) {                                  // 删除菜单条目的接口
          // return ArticleApi.delete(ids);
        },
        // deleteSingleCallback (index, data_or_row_or_id) {
        //   return ecoplanetApi.posAmountConfig_api.delete(data_or_row_or_id);
        // }
      };
    }

  }

</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  // 尝试规范的进行  CSS开发。
</style>
