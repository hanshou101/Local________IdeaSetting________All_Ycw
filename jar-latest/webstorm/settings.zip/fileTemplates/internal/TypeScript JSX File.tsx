import type { FC } from 'react';
import React       from 'react';

export const _ : FC<{}> = ()=>{
    return (<>
    
    </>)
}